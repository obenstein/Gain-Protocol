import React from 'react'
import "./Header.css"
import Navbar from './NavBar/Navbar'
import video from "../Animation Videos/Animation Bubbles.mp4"
function Header() {
    return (
        <div>

            <div className="header__wrapper">
                {/* copied stuff */}
                <header>
                    <div class="header">
                        <nav class="navigation">
                            <a href="#" class="navbar-logo">GAIN <span>PROTOCOL</span></a>
                            <div class="navbar-right">
                                <a href="#">White Paper</a>
                                <a href="#">Protocol</a>
                                <a href="#">Fees</a>
                                <a href="#">Audit</a>
                                <a href="#">Sweepstakes</a>
                                <a href="#">Swap</a>
                                <a href="#">Features</a>
                                <a href="#">Toro Rounds</a>
                                <a href="#">Read Whitepaper</a>



                            </div>
                        </nav>

                        <div class="video-container">
                            {/* <video autoplay={true} id="video-bg">

                                <source src={video} />

                            </video> */}
                            <video id="video-bg" autoPlay={true} muted loop>
                                <source src={video}>
                                </source>
                            </video>
                        </div>
                    </div>
                </header>
                {/* copied stuff */}

                <div className="logo">

                </div>
                {/* <div >
                    <Navbar />
                </div> */}
                <div className="header_icons">

                </div>

            </div >
            {/* <video width="1349" loop autoPlay={true}   >
                <source src={video}>
                </source>
            </video> */}

        </div >
    )
}

export default Header
