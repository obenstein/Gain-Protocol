import './App.css';
import Header from './Header/Header';
function App() {
  return (
    <div className="App">
      <Header> </Header>
    </div>
  );
}

export default App;
